v {xschem version=3.4.8RC file_version=1.3}
G {}
K {}
V {}
S {}
F {}
E {}
N 130 -200 130 -140 {lab=Y}
N 60 -280 90 -280 {lab=B}
N 60 -200 60 -110 {lab=B}
N 60 -110 90 -110 {lab=B}
N 20 -200 60 -200 {lab=B}
N 60 -280 60 -200 {lab=B}
N 250 -200 320 -200 {lab=Y}
N 130 -250 130 -200 {lab=Y}
N 320 -200 320 -90 {lab=Y}
N 320 -290 320 -200 {lab=Y}
N 380 -200 380 -90 {lab=B}
N 380 -200 440 -200 {lab=B}
N 380 -290 380 -200 {lab=B}
N 250 -270 250 -200 {lab=Y}
N 130 -200 250 -200 {lab=Y}
N 130 -330 130 -310 {lab=A}
N 130 -80 130 -60 {lab=A_bar}
N 350 -50 350 -30 {lab=A}
N 350 -350 350 -330 {lab=A_bar}
N -350 -120 -320 -120 {lab=A}
N -350 -280 -320 -280 {lab=A}
N -280 -200 -190 -200 {lab=A_bar}
N -280 -250 -280 -200 {lab=A_bar}
N -370 -200 -350 -200 {lab=A}
N -350 -280 -350 -200 {lab=A}
N -350 -200 -350 -120 {lab=A}
N -280 -200 -280 -150 {lab=A_bar}
N -280 -330 -280 -310 {lab=Vdd}
N -280 -330 -240 -330 {lab=Vdd}
N -280 -350 -280 -330 {lab=Vdd}
N -240 -330 -240 -280 {lab=Vdd}
N -280 -280 -240 -280 {lab=Vdd}
N -280 -120 -240 -120 {lab=GND}
N -240 -120 -240 -70 {lab=GND}
N -280 -70 -240 -70 {lab=GND}
N -280 -90 -280 -70 {lab=GND}
N -280 -70 -280 -30 {lab=GND}
N -160 -520 -130 -520 {lab=A}
N 10 -520 40 -520 {lab=B}
N 180 -520 210 -520 {lab=Vdd}
N 130 -280 170 -280 {lab=Vdd}
N 130 -110 170 -110 {lab=GND}
N 350 -150 350 -90 {lab=Vdd}
N 350 -290 350 -240 {lab=GND}
C {/foss/pdks/gf180mcuD/libs.tech/xschem/symbols/pfet_03v3.sym} 110 -280 0 0 {name=M1
L=0.28u
W=2u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=pfet_03v3
spiceprefix=X
}
C {/foss/pdks/gf180mcuD/libs.tech/xschem/symbols/nfet_03v3.sym} 110 -110 0 0 {name=M2
L=0.28u
W=1u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=nfet_03v3
spiceprefix=X
}
C {/foss/pdks/gf180mcuD/libs.tech/xschem/symbols/nfet_03v3.sym} 350 -310 1 0 {name=M3
L=0.28u
W=1u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=nfet_03v3
spiceprefix=X
}
C {/foss/pdks/gf180mcuD/libs.tech/xschem/symbols/pfet_03v3.sym} 350 -70 3 0 {name=M4
L=0.28u
W=2u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=pfet_03v3
spiceprefix=X
}
C {lab_wire.sym} 130 -330 0 0 {name=p1 sig_type=std_logic lab=A}
C {lab_wire.sym} 130 -60 0 0 {name=p2 sig_type=std_logic lab=A_bar}
C {lab_wire.sym} 350 -350 0 0 {name=p3 sig_type=std_logic lab=A_bar}
C {lab_wire.sym} 350 -30 0 0 {name=p4 sig_type=std_logic lab=A}
C {lab_wire.sym} 20 -200 0 0 {name=p5 sig_type=std_logic lab=B}
C {lab_wire.sym} 440 -200 0 0 {name=p6 sig_type=std_logic lab=B}
C {/foss/pdks/gf180mcuD/libs.tech/xschem/symbols/nfet_03v3.sym} -300 -120 0 0 {name=M5
L=0.28u
W=1u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=nfet_03v3
spiceprefix=X
}
C {/foss/pdks/gf180mcuD/libs.tech/xschem/symbols/pfet_03v3.sym} -300 -280 0 0 {name=M6
L=0.28u
W=2u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=pfet_03v3
spiceprefix=X
}
C {lab_wire.sym} -370 -200 0 0 {name=p7 sig_type=std_logic lab=A}
C {lab_wire.sym} -190 -200 0 0 {name=p8 sig_type=std_logic lab=A_bar}
C {vsource.sym} -190 -520 1 0 {name=V1 value="pulse(0 3.3 0 100p 100p 10n 20n)" savecurrent=false}
C {vsource.sym} -20 -520 1 0 {name=V2 value="pulse(0 3.3 0 100p 100p 20n 40n)" savecurrent=false}
C {vsource.sym} 150 -520 1 0 {name=V3 value=3.3 savecurrent=false}
C {gnd.sym} 120 -520 1 0 {name=l1 lab=GND}
C {gnd.sym} -50 -520 1 0 {name=l2 lab=GND}
C {gnd.sym} -220 -520 1 0 {name=l3 lab=GND}
C {lab_wire.sym} -130 -520 0 0 {name=p11 sig_type=std_logic lab=A}
C {lab_wire.sym} 40 -520 0 0 {name=p12 sig_type=std_logic lab=B}
C {lab_wire.sym} -280 -350 0 0 {name=p9 sig_type=std_logic lab=Vdd}
C {lab_wire.sym} 210 -520 0 0 {name=p13 sig_type=std_logic lab=Vdd}
C {gnd.sym} -280 -30 0 0 {name=l4 lab=GND}
C {lab_pin.sym} 250 -270 0 0 {name=p10 sig_type=std_logic lab=Y}
C {lab_wire.sym} 170 -280 0 0 {name=p14 sig_type=std_logic lab=Vdd}
C {lab_wire.sym} 350 -150 0 0 {name=p15 sig_type=std_logic lab=Vdd}
C {gnd.sym} 170 -110 3 0 {name=l5 lab=GND}
C {gnd.sym} 350 -240 0 0 {name=l6 lab=GND}
C {simulator_commands_shown.sym} 250 -810 0 0 {
name=Libs_Ngspice
simulator=ngspice
only_toplevel=false
value="
.include /foss/pdks/gf180mcuD/libs.tech/ngspice/design.ngspice
.lib /foss/pdks/gf180mcuD/libs.tech/ngspice/sm141064.ngspice typical
"
      }
C {simulator_commands_shown.sym} 260 -570 0 0 {name=SimulatorNGSPICE
simulator=ngspice
only_toplevel=false 
value="
.control
tran 0.01n 40n
save all
write XOR.raw
.endc
"}
