v {xschem version=3.4.8RC file_version=1.3}
G {}
K {}
V {}
S {}
F {}
E {}
N 510 -210 510 -150 {lab=Y}
N 440 -290 470 -290 {lab=B}
N 440 -210 440 -120 {lab=B}
N 440 -120 470 -120 {lab=B}
N 410 -210 440 -210 {lab=B}
N 440 -290 440 -210 {lab=B}
N 510 -260 510 -210 {lab=Y}
N 810 -210 810 -120 {lab=B}
N 750 -320 750 -210 {lab=Y}
N 750 -210 750 -120 {lab=Y}
N 630 -280 630 -210 {lab=Y}
N 510 -210 630 -210 {lab=Y}
N 510 -90 510 -60 {lab=A_bar}
N 780 -380 780 -360 {lab=A}
N 780 -80 780 -60 {lab=A_bar}
N 30 -130 60 -130 {lab=A}
N 30 -290 60 -290 {lab=A}
N 100 -210 260 -210 {lab=A_bar}
N 100 -260 100 -210 {lab=A_bar}
N 10 -210 30 -210 {lab=A}
N 30 -290 30 -210 {lab=A}
N 30 -210 30 -130 {lab=A}
N 100 -210 100 -160 {lab=A_bar}
N 100 -340 100 -320 {lab=VDD}
N 100 -340 140 -340 {lab=VDD}
N 100 -360 100 -340 {lab=VDD}
N 140 -340 140 -290 {lab=VDD}
N 100 -290 140 -290 {lab=VDD}
N 100 -130 140 -130 {lab=GND}
N 140 -130 140 -80 {lab=GND}
N 100 -80 140 -80 {lab=GND}
N 100 -100 100 -80 {lab=GND}
N 100 -80 100 -40 {lab=GND}
N 510 -290 550 -290 {lab=VDD}
N 510 -120 550 -120 {lab=GND}
N 780 -320 780 -260 {lab=VDD}
N 780 -170 780 -120 {lab=GND}
N 630 -210 750 -210 {lab=Y}
N 810 -210 880 -210 {lab=B}
N 810 -320 810 -210 {lab=B}
N 880 -470 880 -210 {lab=B}
N 410 -470 880 -470 {lab=B}
N 410 -470 410 -210 {lab=B}
N 400 -210 410 -210 {lab=B}
N 510 -380 510 -320 {lab=A}
N 510 -380 780 -380 {lab=A}
N 260 -210 260 -60 {lab=A_bar}
N 260 -60 510 -60 {lab=A_bar}
N 510 -60 780 -60 {lab=A_bar}
N 30 -410 30 -290 {lab=A}
N 30 -410 510 -410 {lab=A}
N 510 -410 510 -380 {lab=A}
N 140 -80 550 -80 {lab=GND}
N 550 -120 550 -80 {lab=GND}
N 550 -170 550 -120 {lab=GND}
N 550 -170 780 -170 {lab=GND}
N 140 -340 550 -340 {lab=VDD}
N 550 -340 550 -290 {lab=VDD}
N 550 -290 550 -260 {lab=VDD}
N 550 -260 780 -260 {lab=VDD}
C {/foss/pdks/gf180mcuD/libs.tech/xschem/symbols/pfet_03v3.sym} 490 -290 0 0 {name=M1
L=0.28u
W=2u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=pfet_03v3
spiceprefix=X
}
C {/foss/pdks/gf180mcuD/libs.tech/xschem/symbols/nfet_03v3.sym} 490 -120 0 0 {name=M2
L=0.28u
W=1u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=nfet_03v3
spiceprefix=X
}
C {/foss/pdks/gf180mcuD/libs.tech/xschem/symbols/nfet_03v3.sym} 780 -100 3 0 {name=M3
L=0.28u
W=1u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=nfet_03v3
spiceprefix=X
}
C {/foss/pdks/gf180mcuD/libs.tech/xschem/symbols/pfet_03v3.sym} 780 -340 1 0 {name=M4
L=0.28u
W=2u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=pfet_03v3
spiceprefix=X
}
C {ipin.sym} 400 -210 0 0 {name=p5 sig_type=std_logic lab=B}
C {/foss/pdks/gf180mcuD/libs.tech/xschem/symbols/nfet_03v3.sym} 80 -130 0 0 {name=M5
L=0.28u
W=1u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=nfet_03v3
spiceprefix=X
}
C {/foss/pdks/gf180mcuD/libs.tech/xschem/symbols/pfet_03v3.sym} 80 -290 0 0 {name=M6
L=0.28u
W=2u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=pfet_03v3
spiceprefix=X
}
C {ipin.sym} 10 -210 0 0 {name=p7 sig_type=std_logic lab=A}
C {lab_wire.sym} 190 -210 0 0 {name=p8 sig_type=std_logic lab=A_bar}
C {iopin.sym} 100 -360 0 0 {name=p9 sig_type=std_logic lab=VDD}
C {opin.sym} 630 -280 0 0 {name=p10 sig_type=std_logic lab=Y}
C {iopin.sym} 100 -40 0 0 {name=p11 sig_type=std_logic lab=GND}
