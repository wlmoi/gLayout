# ALIGN-GF180 Wrapper Verification

- Design: `telescopic_ota`
- Status: PASS