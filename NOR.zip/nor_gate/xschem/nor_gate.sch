v {xschem version=3.4.8RC file_version=1.3}
G {}
K {}
V {}
S {}
F {}
E {}
N 0 150 0 170 {lab=Vss}
N -190 -190 -170 -190 {lab=in1}
N 0 -250 0 -240 {lab=Vdd}
N -170 -190 -110 -190 {lab=in1}
N -80 0 -80 70 {lab=out}
N -80 0 140 0 {lab=out}
N 80 0 80 70 {lab=out}
N -0 -40 0 -0 {lab=out}
N 0 -50 0 -40 {lab=out}
N -80 130 -80 150 {lab=Vss}
N -80 150 -0 150 {lab=Vss}
N -0 150 80 150 {lab=Vss}
N 80 130 80 150 {lab=Vss}
N 0 -160 -0 -110 {lab=#net1}
N -0 -240 0 -220 {lab=Vdd}
N -110 -80 -40 -80 {lab=in2}
N -110 -190 -40 -190 {lab=in1}
N -190 -80 -140 -80 {lab=in2}
N -140 -80 -120 -80 {lab=in2}
N -120 -80 -110 -80 {lab=in2}
N -40 100 40 100 {lab=in2}
N -50 100 -40 100 {lab=in2}
N -50 -80 -50 100 {lab=in2}
N -150 100 -120 100 {lab=in1}
N -150 -190 -150 100 {lab=in1}
N -0 -190 30 -190 {lab=Vdd}
N 30 -240 30 -190 {lab=Vdd}
N -0 -240 30 -240 {lab=Vdd}
N -0 -80 30 -80 {lab=Vdd}
N 30 -190 30 -80 {lab=Vdd}
N 80 100 110 100 {lab=Vss}
N 110 100 110 150 {lab=Vss}
N 80 150 110 150 {lab=Vss}
N -80 100 -60 100 {lab=Vss}
N -60 100 -60 150 {lab=Vss}
C {ipin.sym} -190 -190 0 0 {name=p1 lab=in1}
C {opin.sym} 140 0 0 0 {name=p2 lab=out}
C {symbols/pfet_03v3.sym} -20 -80 0 0 {name=M3
L=0.42u
W=2.00u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=pfet_03v3
spiceprefix=X
}
C {symbols/nfet_03v3.sym} -100 100 0 0 {name=M1
L=1.00u
W=0.42u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=nfet_03v3
spiceprefix=X
}
C {ipin.sym} 0 -250 1 0 {name=p3 lab=Vdd}
C {ipin.sym} 0 170 3 0 {name=p4 lab=Vss}
C {symbols/pfet_03v3.sym} -20 -190 0 0 {name=M2
L=0.42u
W=2.00u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=pfet_03v3
spiceprefix=X
}
C {symbols/nfet_03v3.sym} 60 100 0 0 {name=M4
L=1.00u
W=0.42u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=nfet_03v3
spiceprefix=X
}
C {ipin.sym} -190 -80 0 0 {name=p5 lab=in2}
