# ALIGN-GF180 Wrapper Verification

- Design: `telescopic_ota`
- Netlist: `/content/telescopic_ota_sky130_example_gf180.sp`
- GF180 PDK: `/tmp/align_gf180_verify_itxokt4_/mock_align_pdk/gf180mcu`
- DRC report: `/content/ALIGN-GF180 Wrapper/outputs/verification/drc/telescopic_ota/telescopic_ota.rpt`
- LVS report: `/content/ALIGN-GF180 Wrapper/outputs/verification/lvs/telescopic_ota/telescopic_ota_lvs.rpt`

## Results
- Translation: PASS
- DRC: SKIPPED
- LVS: SKIPPED
- Input String Check: FAIL

## Notes
- DRC/LVS are only real when Magic/Netgen and a real GDS are available.
- In this workspace the tools are absent, so DRC/LVS are reported as skipped.
